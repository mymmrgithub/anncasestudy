import React, { useState, useEffect } from "react";

function SearchProducts() {
  const url = "http://localhost:8080/api/v1/products/4";
  const [searchstr, setSearchstr,] = useState();
  const [data, setData] = useState([]);
  const prodreq = { "prod":"", "type":"" };
  const handleError = response => {
 
    return {"Error Fetch":"Error Occurred"};
}
  const fetchInfo = () => {
    return fetch(url,{
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        
        mode: 'cors',
        cache:'no-cache',
        credentials:'same-origin',
        body: JSON.stringify(prodreq)
    })
      .then((res) => res.json())
      .then((d) => setData(d))
  }


  useEffect(() => {
    fetchInfo();
  }, []);
  async function searchthis(searchstr) {
    const prodreq = { "prod":"", "type":"" };
  //  alert("INPIUT"+JSON.stringify(credentials));
    try {
       // alert(prodreq);
        let url="http://localhost:8080/api/v1/products/id/"+searchstr;

        const response = await fetch(url,
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                
                mode: 'cors',
                cache:'no-cache',
                credentials:'same-origin',
                body: JSON.stringify(prodreq)
            }
        );
        //alert(JSON.stringify(response.json()));
        if (!response.ok) {
            return handleError(response);
        }
        const json = await response.json();
        setData(json);
        //alert(JSON.stringify(json));
        return Promise.resolve(json);
    } catch (error) {
        //alert(error);
        return Promise.reject(error);
    }
}
  const searchProducts = async e => {
    //alert("in search");
    e.preventDefault();
    const response = await searchthis(searchstr)();
    
  }
  const loadProducts = async e => {
    //alert("in loading");
    e.preventDefault();
    const response = await fetchproducts()();
    
  }
  async function fetchproducts() {
    const prodreq = { "prod":"", "type":"" };
  //  alert("INPIUT"+JSON.stringify(credentials));
    try {
       // alert(prodreq);
        const response = await fetch('http://localhost:8080/api/v1/products/14',
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                
                mode: 'cors',
                cache:'no-cache',
                credentials:'same-origin',
                body: JSON.stringify(prodreq)
            }
        );
        //alert(JSON.stringify(response.json()));
        if (!response.ok) {
            return handleError(response);
        }
        const json = await response.json();
        setData(json);
        //alert(JSON.stringify(json));
        return Promise.resolve(json);
    } catch (error) {
        //alert(error);
        return Promise.reject(error);
    }
}
  return (
  

    <div className="App">
    
      
    <div className="login-wrapper">
    
    <form >
      <p style={{ color: "green" }}>Search for Product</p> <input type="text" onChange={e => setSearchstr(e.target.value)}  /> <p> <button onClick={searchProducts}>Search</button></p>
      <div>
        <button onClick={loadProducts}>Load All Product</button>
      </div>
    </form>
  </div>
  
      <center>
    
         <thead>
              <th style={{ color: "green" }}>product_id</th>
              <th style={{ color: "green" }}>product_img</th>
              <th style={{ color: "green" }}>product_name</th>
              <th style={{ color: "green" }}>product_type</th>
              <th style={{ color: "green" }}>available_qty</th>
              <th style={{ color: "green" }}>product_desc</th>
              <th style={{ color: "green" }}>units</th>
              <th style={{ color: "green" }}>price_per_units</th>
        </thead>
        <tbody>
          {data.map((product,index) => 
              <tr>
              <td>{product.product_id}</td>
              <td>{product.product_img}</td>
              <td>{product.product_name}</td>
              <td>{product.product_type}</td>
              <td>{product.available_qty}</td>
              <td>{product.product_desc}</td>
              <td>{product.units}</td>
              <td>{product.price_per_units}</td>
              </tr>)
          }
          </tbody>
      </center>
    </div>
  );
}

export default SearchProducts;