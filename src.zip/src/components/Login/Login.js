import React, { useState } from 'react';
import PropTypes from 'prop-types';
import './Login.css';
const handleError = response => {
 
    return {"Invalid":" Invalid Credential"};
}
async function loginUser(customer_id,password) {
    const credentials = { "customer_id":customer_id.username, "password":customer_id.password };
  //  alert("INPIUT"+JSON.stringify(credentials));
    try {
        //alert(customer_id + ":"+password);
        const response = await fetch('http://localhost:8080/api/v1/auth/login',
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                
                mode: 'cors',
                cache:'no-cache',
                credentials:'same-origin',
                body: JSON.stringify(credentials)
            }
        );
        //alert(JSON.stringify(response.json()));
        if (!response.ok) {
            return handleError(response);
        }
        const json = await response.json();
        //alert(JSON.stringify(json));
        return Promise.resolve(json);
    } catch (error) {
        //alert(error);
        return Promise.reject(error);
    }
}

export default function Login({ setToken }) {
  const [username, setUserName,] = useState();
  
  const [password, setPassword] = useState();
  const [customer_id, setCustomer_id] = useState();
  const [email, setEmail] = useState();

  const handleSubmit = async e => {
    e.preventDefault();
    const token = await loginUser({
        username,password
        });
    setToken(token);
  }

  return(
    <div className="login-wrapper">
      <h1>Please Log In</h1>
      <form onSubmit={handleSubmit}>
        <label>
          <p>Customer Code</p>
          <input type="text" onChange={e => setUserName(e.target.value)} />
        </label>
        <label>
          <p>Password</p>
          <input type="password" onChange={e => setPassword(e.target.value)} />
        </label>
        <div>
          <button type="submit">Submit</button>
        </div>
      </form>
    </div>
  )
}

Login.propTypes = {
  setToken: PropTypes.func.isRequired
};